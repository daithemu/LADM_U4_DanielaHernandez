package com.example.ladm_u4_practica2_danielahernandez

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class lienzo(p:MainActivity): View(p){

    var iconodany = BitmapFactory.decodeResource(resources,R.drawable.iconodani)
    var zona = BitmapFactory.decodeResource(resources,R.drawable.zona)
    var city = BitmapFactory.decodeResource(resources,R.drawable.city)

    var dany = figuras(0,100,iconodany)
    var zonafantasma = figuras(0,0,zona)
    var amitypark = figuras(0,0,city)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        var paint = Paint()

        zonafantasma.pintar(c,paint)
        amitypark.pintar(c,paint)
        dany.pintar(c,paint)

    }


}