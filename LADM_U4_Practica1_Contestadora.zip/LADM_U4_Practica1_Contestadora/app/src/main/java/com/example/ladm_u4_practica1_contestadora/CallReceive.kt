package com.example.ladm_u4_practica1_contestadora

import android.content.BroadcastReceiver
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.telephony.PhoneStateListener
import android.telephony.SmsMessage
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast


class CallReceive : BroadcastReceiver() {

    var numeroEntrante = ""
    var incomingFlag = false

    override fun onReceive(context: Context, intent: Intent) {

        if(intent.getStringExtra(TelephonyManager.EXTRA_STATE).equals(TelephonyManager.EXTRA_STATE_OFFHOOK)){
            incomingFlag = false
            //muestra(context, "Estas en llamada")
            numeroEntrante = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)
            Log.e(TAG, "call OUT:$numeroEntrante")

        }else if (intent.getStringExtra(TelephonyManager.EXTRA_STATE).equals(TelephonyManager.EXTRA_STATE_IDLE)){
           incomingFlag = false
            muestra(context, "llamada terminada")

        }else if(intent.getStringExtra(TelephonyManager.EXTRA_STATE).equals(TelephonyManager.EXTRA_STATE_RINGING)){
            incomingFlag = true
            numeroEntrante = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)
            Log.e(TAG, "RINGING :$numeroEntrante")

            try {
                var baseDatos = BaseDeDatos(context, "llamadas", null,1)
                var insertar = baseDatos.writableDatabase
                var SQL = "INSERT INTO ENTRANTS VALUES('${numeroEntrante}')"
                insertar.execSQL(SQL)
                baseDatos.close()

            }catch (err: SQLiteException){
                Toast.makeText(context, err.message,Toast.LENGTH_LONG).show()
            }

            Toast.makeText(context, "Entró contenido",Toast.LENGTH_LONG).show()
        }
    }

    fun muestra (context : Context, message: String ){
        Toast.makeText(context,message,Toast.LENGTH_LONG).show()
    }

}


