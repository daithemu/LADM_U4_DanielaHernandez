package com.example.ladm_u4_practica1_contestadora

import android.content.pm.PackageManager
import android.database.sqlite.SQLiteException
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CallLog
import android.telephony.PhoneStateListener
import android.telephony.SmsManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val siPermiso = 1
    val siPermisoLlamadas = 2
    val siPermisoEnvio = 3

    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if(ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.READ_PHONE_STATE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.READ_PHONE_STATE),siPermisoLlamadas)
        }

        if(ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.READ_CALL_LOG)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.READ_CALL_LOG),siPermiso)
        }

        if(ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {
            //solicitamos el permiso en caso de queno esté otorgado
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.SEND_SMS), siPermisoEnvio)
        }else{
            EnviarMensajes()
        }


    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode==siPermiso){
            //al mandar el permiso de forma imediata llama el metodo
            setTitle("PERMISO OTORGADO")
        }
        if (requestCode==siPermisoLlamadas){
            mensajeLlamadas()
        }
        if(requestCode==siPermisoEnvio){
            EnviarMensajes()
        }
    }

    private fun EnviarMensajes(){
        try {
            val cursor = BaseDeDatos(this,"llamadas",null,1)
                .readableDatabase
                .rawQuery("SELECT * FROM LLAMADAS",null)

            if(cursor.moveToFirst()){
                do{
                    val numeroC = cursor.getString(0)
                    if(numeroC == txtNumeroDeseado.text.toString()){
                        enviaM1()
                    }
                    if(numeroC==txtMensajeNoDeseado.text.toString()){
                        enviaM2()
                    }
                }while (cursor.moveToNext())
            }else{
                Toast.makeText(this,"sin llamadas",Toast.LENGTH_LONG).show()
            }

        }catch (err:SQLiteException){
            Toast.makeText(this, err.message,Toast.LENGTH_LONG).show()
        }

    }

    fun enviaM1(){
        SmsManager.getDefault().sendTextMessage(txtNumeroDeseado.text.toString(),null,
            //mensaje
            txtMensajeDeseado.text.toString(),null,null)
        Toast.makeText(this,"se envió el sms deseado",Toast.LENGTH_LONG).show()
    }

    fun enviaM2(){
        SmsManager.getDefault().sendTextMessage(txtNumeroNoDeseado.text.toString(),null,
            //mensaje
            txtMensajeNoDeseado.text.toString(),null,null)
        Toast.makeText(this,"se envió el sms deseado",Toast.LENGTH_LONG).show()
    }

    private fun leerRegistroLlamadas() {
        var resultado = ""

        val tipos = arrayOf("","entrante","saliente","perdida")

        val cursorLlamadas = contentResolver.query(
            Uri.parse("content://call_log/calls"),
         null,null,null,null
        )
        if(cursorLlamadas!!.moveToFirst()){
            do {
                var telefono = cursorLlamadas.getInt(
                    cursorLlamadas.getColumnIndex(CallLog.Calls.NUMBER)
                )
                var tipoLlamada = cursorLlamadas.getString(
                    cursorLlamadas.getColumnIndex(CallLog.Calls.TYPE )
                )
                //resultado+="Telefono" +telefono+"\nTypo: "+tipoLlamada
                try {
                    var baseDatos = BaseDeDatos(this, "llamadas", null,1)
                    var insertar = baseDatos.writableDatabase
                    var SQL = "INSERT INTO LLAMADAS VALUES('${telefono}','${tipoLlamada}')"
                    insertar.execSQL(SQL)
                    baseDatos.close()

                }catch (err: SQLiteException){
                    Toast.makeText(this, err.message, Toast.LENGTH_LONG).show()
                }
            }while (cursorLlamadas.moveToNext())
            //textView.setText(resultado)
        }else{
            resultado= "Llamadas: \nno hay registro de llamadas"
        }
    }

    private fun mensajeLlamadas() {
        AlertDialog.Builder(this)
            .setMessage("se otorgo permiso para Llamadas")
            .show()
    }

}

